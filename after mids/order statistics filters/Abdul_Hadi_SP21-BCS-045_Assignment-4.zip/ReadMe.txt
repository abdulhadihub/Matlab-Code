% Example command to run with parameters
SP21_BCS_045('C:\Users\Abdul Hadi\Desktop\test images\020.jpeg', 3, 100, 50, 2);